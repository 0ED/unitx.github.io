package memorySlot.rule;
import javax.swing.JFrame;

public class RuleView extends JFrame {
    public RuleView() {
        //バツボタンを押したときにアプリケーション自体は終了せず、このウィンドウを閉じる
        setDefaultCloseOperation(DISPOSE_ON_CLOSE );
        setSize(400, 700);
        getContentPane().setLayout(null);
        setVisible(true);
    }
}