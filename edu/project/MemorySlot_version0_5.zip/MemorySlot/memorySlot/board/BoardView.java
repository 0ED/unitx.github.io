package memorySlot.board;
import memorySlot.MemorySlot;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;

public class BoardView extends JPanel {
    
    private Image boardImage;
    
    public BoardView() {
        setOpaque(false);
        setBounds(0, 0, MemorySlot.FRAME_WIDTH, MemorySlot.FRAME_HEIGHT);
        installBoardImage();
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        g.drawImage(boardImage, 0, 0, MemorySlot.FRAME_WIDTH, MemorySlot.FRAME_HEIGHT, this);
    }
    
    private void installBoardImage() {
        String dir=System.getProperty("user.dir")+File.separator;
        String file = "MemorySlot/Image/background/background.png";
        boardImage = Toolkit.getDefaultToolkit().getImage(dir+file);
    }
    
}