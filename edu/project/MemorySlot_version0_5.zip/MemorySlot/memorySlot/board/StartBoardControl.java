package memorySlot.board;
import memorySlot.MemorySlot;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class StartBoardControl implements ActionListener {
    
    private MemorySlot memorySlot;
    private StartBoardView startBoardView;
    
    public StartBoardControl(MemorySlot memorySlot, StartBoardView view) {
        this.memorySlot = memorySlot;
        this.startBoardView = view;
        startBoardView.addToButtonActionListener(this);
    }
    
    public void actionPerformed(ActionEvent ev){
        JButton botton = (JButton) ev.getSource();
        if(botton.getText().equals("スタート")) { //ここでボードの切り替えを行う
            memorySlot.startGame();
        }
        if(botton.getText().equals("ルール説明")) System.out.println("ルール説明が出るようにする。");
    }
    
}