package memorySlot.board;
import memorySlot.MemorySlot;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.BorderLayout;


public class StartBoardView extends BoardView {
    private JPanel bottonArea;
    private JButton startButton;
    private JButton ruleButton;
    private static final int BUTTON_WIDTH = 250;
    private static final int BUTTON_HEIGHT = 50;
    private static final int VERTICAL_GAP = 20;
    
    public StartBoardView() {
        super();
        setLayout(null);
        setOpaque(true); //背景を不透明に
        setBackground(new Color(0,90,0));
        startButton = new JButton("スタート");
        ruleButton = new JButton("ルール説明");

        bottonArea = new JPanel();
        bottonArea.setOpaque(false);
        bottonArea.setLayout(new GridLayout(2,1,0,VERTICAL_GAP) );
        bottonArea.setBounds(   (MemorySlot.FRAME_WIDTH/2)-(BUTTON_WIDTH/2),
                                (MemorySlot.FRAME_HEIGHT/2)-(BUTTON_HEIGHT+VERTICAL_GAP),
                                BUTTON_WIDTH,
                                BUTTON_HEIGHT*2+VERTICAL_GAP
                              );
        bottonArea.add(startButton);
        bottonArea.add(ruleButton);
        add(bottonArea);
    }

    void addToButtonActionListener(ActionListener actionListener) { //Controlから呼ぶ
        startButton.addActionListener(actionListener);
        ruleButton.addActionListener(actionListener);
    }
    
    
}