package memorySlot.board;
import memorySlot.MemorySlot;
import memorySlot.Mediator;
import memorySlot.trump.TrumpModel;
import memorySlot.trump.TrumpArea;
import memorySlot.bet.*;
//import memorySlot.score.*;
import memorySlot.slot.*;
import java.util.HashMap;
import java.awt.Color;
import javax.swing.JLayeredPane;

public class GameBoardView extends JLayeredPane implements Mediator {
    
    //トランプ
    private TrumpArea trumpArea;
    
    //スロット&確率分布
    private SlotModel slotModel;
    private SlotView slotView;
    private SlotControl slotControl;
    private ProbabilityView probabilityView;
    
    //ベット
    private BetModel betModel;
    private BetView betView;
    private BetControl betControl;
    
    /*
    //スコア
    private ScoreModel scoreModel;
    private ScoreView scoreView;
    private ScoreControl scoreControl;
    */
    
    public GameBoardView() {
        setOpaque(true); //最背面なので透明でない
        setLayout(null);
        setBounds(0, 0, MemorySlot.FRAME_WIDTH, MemorySlot.FRAME_HEIGHT);
        setBackground(new Color(0,90,0));
        
        /* ボード */
        BoardView boardView = new BoardView(); //ここの位置（setLocation）で出来るようにしておく
        
        /* トランプ */
        TrumpArea trumpArea = new TrumpArea();
        
        /* スロット */
        slotModel = new SlotModel();
        slotView = new SlotView(slotModel);
        probabilityView = new ProbabilityView(slotModel);
        slotControl = new SlotControl(slotModel,slotView,probabilityView);
        
        /* ベット */
        betModel = new BetModel();
        betView = new BetView(betModel);
        betControl = new BetControl(betModel, betView);
        
        
        /* 配置 */
        trumpArea.setLocation(  (MemorySlot.FRAME_WIDTH/2)-(TrumpArea.WIDTH/2),
                                (MemorySlot.FRAME_HEIGHT/2)-(TrumpArea.HEIGHT/2)-50     );
        slotView.setLocation(       (MemorySlot.FRAME_WIDTH/2)-(SlotView.WIDTH/2),
                                    (MemorySlot.FRAME_HEIGHT/2)-(SlotView.HEIGHT/2)-50-5      );
        probabilityView.setLocation(    20,
                                        (MemorySlot.FRAME_HEIGHT/2)-(probabilityView.HEIGHT/2)  );
        betView.setLocation(    MemorySlot.FRAME_WIDTH - BetView.WIDTH,
                                MemorySlot.FRAME_HEIGHT - BetView.HEIGHT );
        
        /* レイヤー設定 */
        setLayer(betView,3);
        setLayer(boardView,2); //前面はタイトルとトランプの「飾り」
        setLayer(slotView,1);
        setLayer(probabilityView,1);
        setLayer(trumpArea,1); 
        setLayer(this,0); //最背面は緑色のみ
        
        add(betView);
        add(boardView);
        add(slotView);
        add(probabilityView);
        add(trumpArea);
        
        /* Mediatorの設定 */
        betControl.setMediator(this);
        slotControl.setMediator(this);
        trumpArea.setMediator(this);
    }
    
    
    
    
    
    

    /**
     * ベットが追加されると呼び出され、スコアをベットの金額だけ減らす
     */
    public void removeScoreByBet() {
//        scoreModel.removeScore(betModel.getBet());
    }
    
    
    /**
     * トランプが2枚オープンすると呼び出される。
     * @param trump0 オープンされた1枚目のトランプデータ
     * @param trump1 オープンされた2枚目のトランプデータ
     */
    public void happenCardEvent(TrumpModel trump0, TrumpModel trump1, String trumpCombination) {
        
        /* 「フラッシュ」は確率を1段階up */
        if(trumpCombination.equals("フラッシュ")) {
            if(checkNewTrumpCombination(trump0, trump1)) {
                System.out.println("初めて捲った");
                slotModel.addProbabilityLevel1();
            }
        }
        
        /* 「ブラックジャック」は確率を2段階up */
        if(trumpCombination.equals("ブラックジャック")) {
            if(checkNewTrumpCombination(trump0, trump1)) {
                System.out.println("初めて捲った");
                slotModel.addProbabilityLevel2();
            }
            
        }
        
        /* 「フラッシュ&ブラックジャック」は確率を3段階up */
        if(trumpCombination.equals("フラッシュ&ブラックジャック")) {
            if(checkNewTrumpCombination(trump0, trump1)) {
                System.out.println("初めて捲った");
                slotModel.addProbabilityLevel1();
                slotModel.addProbabilityLevel2();
            }
        }
        
        /*
         * 「スロット」はスロットをスタートさせ、スロットが終われば確率レベルを0にする
         * また賭け金の2倍、スコアが手に入る
         */
        if(trumpCombination.equals("スロット")) {
            slotControl.startSlot();
            slotModel.clearProbabilityLevel();
//            scoreControl.addScore(2*betModel.getChip());
        }
        
        /* 確率を更新 */
        probabilityView.repaint();

    }
    
    
    
    /**
     * スロットがそろったときのイベント
     * @param slotMark スロットのマーク
     */
    public synchronized void hitSlot(int slotMark) { //synchronizedによって、1つのスレッドしか受け付けない
        switch(slotMark) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            default:
                System.out.println("ここが実行されればバグ。Class: GameBoardView");
                break;
        }
    }
    
    
    
    /* トランプの組み合わせを記憶する。*/
    private HashMap<TrumpModel,TrumpModel> trumpCombinationMap = new HashMap<TrumpModel,TrumpModel>();
    
    /**
     * 新しいトランプの組み合わせがあったかをチェックする
     * @param trump0 オープンされた1枚目のトランプデータ
     * @param trump1 オープンされた2枚目のトランプデータ
     * @return 初めてオープンされた組み合わせかどうか
     */
    private boolean checkNewTrumpCombination(TrumpModel trump0, TrumpModel trump1) {
        if( trump0 == trumpCombinationMap.get(trump1) || trump1 == trumpCombinationMap.get(trump0) ) {
            return false;
        }
        else {
            trumpCombinationMap.put(trump0,trump1);
            return true;
        }
    }
}