package memorySlot;

public interface Colleague {
    public abstract void setMediator(Mediator mediator);
}