package memorySlot.slot;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.awt.Color;
import java.awt.Font;

public class ProbabilityView extends JPanel{
    public final int WIDTH = 200;
    public final int HEIGHT = 300;
	private final int HitSum = 7;
	SlotModel slotModel;
	String[] probability = new String[7];
	private Image[] images = new Image[7];
	
	public ProbabilityView(SlotModel slotModel) {
        this.slotModel = slotModel;
        setOpaque(false);
		setSize(WIDTH, HEIGHT);
		installSlotMarkImage(HitSum);
	}
	
	public void paint(Graphics g){
		probability=slotModel.getProbabilityString();
		super.paint(g);
        g.setFont(new Font("Serif",Font.BOLD, 18));
        g.setColor(Color.WHITE);
		for(int i=0;i<7;i++){
			for(int j=0;j<3;j++){
				g.drawImage(images[i],40*j,40*i, this);
			}
			g.drawString(probability[i]+"%", 130, 40*i+30);
		}
	}
	
	private void installSlotMarkImage(int hit){
        String dir=System.getProperty("user.dir")+File.separator;
		for(int iImg=0;iImg<hit;iImg++){
			String[] filename = new String[hit];
			filename[iImg] = "memorySlot/Image/slot/mark"+iImg+".png";
			images[iImg] = Toolkit.getDefaultToolkit().getImage(dir+filename[iImg]);
		}
	}
}