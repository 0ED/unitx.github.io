package memorySlot.slot;
import memorySlot.Mediator;
import memorySlot.Colleague;
import java.awt.*;
import javax.swing.*;

public class SlotControl implements Colleague {
    private Mediator mediator;
	SlotModel slotModel;
	SlotView slotView;
	ProbabilityView probabilityView;
	
	public SlotControl(SlotModel slotModel, SlotView slotView, ProbabilityView probabilityView){
		this.slotModel = slotModel;
		this.slotView = slotView;;
		this.probabilityView = probabilityView;
	}
	
	public void startSlot(){
        int[] ans = slotModel.getRandomSlotMark();
		slotView.installSlotMarkImage(ans[0],ans[1],ans[2]);
		slotView.repaint();
		if(ans[0]==ans[1]&&ans[1]==ans[2]){
            /* そろったマークによって、数秒まつ可能性がある。*/
			mediator.hitSlot(ans[0]); 
		}
	}
    
    //Mediator実装クラスから呼び出す
    public void setMediator(Mediator mediator) {
        this.mediator = mediator;
    }
    
}

