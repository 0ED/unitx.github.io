package memorySlot.slot;
import javax.swing.*;
import java.awt.*;
import java.io.File;

public class SlotView extends JPanel{ //implements Runnable{
	
	public static final int WIDTH = 230;
    public static final int HEIGHT = 140;
	public static final int  INTERVAL_TIME = 90;
	
	private SlotModel slotModel;
	private Image[] slotMarkImages;
	private Image slotBoardImage;
	private Image shadowImage;
	
	public SlotView(SlotModel slotModel) {
        this.slotModel = slotModel;
        this.slotMarkImages = new Image[3];
        setOpaque(false);
        setLayout(null);
		setSize(WIDTH, HEIGHT);
		installSlotBoardImage();
        installSlotMarkImage(0,0,0);
	}
	
	public void paint(Graphics g) {
        super.paint(g);
        g.drawImage(slotBoardImage,0, 0, WIDTH, HEIGHT, this);
		for(int i=0;i<3;i++){
			g.drawImage(slotMarkImages[i],62*i+30,62, this);
		}
        g.drawImage(shadowImage, 26, 70,this);
	}
	
	public void installSlotMarkImage(int aImg,int bImg,int cImg){
        String dir=System.getProperty("user.dir")+File.separator;
		String[] filename = new String[3];
		filename[0] = "memorySlot/Image/slot/mark"+aImg+".png";
		filename[1] = "memorySlot/Image/slot/mark"+bImg+".png";
		filename[2] = "memorySlot/Image/slot/mark"+cImg+".png";
		for(int i=0; i<3; i++) {
            slotMarkImages[i] = Toolkit.getDefaultToolkit().getImage(dir+filename[i]);
        }
	}
	
	public void installSlotBoardImage(){
        String dir=System.getProperty("user.dir")+File.separator;
		String file1 = "memorySlot/Image/slot/slot.png";
		String file2 = "memorySlot/Image/slot/shadow.png";
		slotBoardImage = Toolkit.getDefaultToolkit().getImage(dir+file1);
		shadowImage = Toolkit.getDefaultToolkit().getImage(dir+file2);
	}
}