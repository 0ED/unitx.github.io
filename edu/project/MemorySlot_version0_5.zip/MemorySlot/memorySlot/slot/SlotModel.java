package memorySlot.slot;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;

public class SlotModel{
	private static final double[] PROBABILITY = new double[]{0.03,0.07,0.10,0.13,0.17,0.20,0.30};
	private static final double INITvariable = 0.10;//暫定デフォ0.70
	private static final double UPvariable = 0.40;//暫定デフォ0.10
	private double variable =INITvariable;
	
	public void addProbabilityLevel1(){
		variable = INITvariable + UPvariable;
	}
	
	public void addProbabilityLevel2(){
		variable = INITvariable + UPvariable + UPvariable;
	}
	
	public void clearProbabilityLevel(){
		variable = INITvariable;
	}
	

	
	public int[] getRandomSlotMark(){
		int ansSlot[] = new int[3];
		int iSum;
		//(int)(Math.random() * 7)
		double rand = Math.random();
		double nowProbability;
		
		nowProbability = 0;
		for(iSum=0;iSum<7;iSum++){//１個目の絵柄を決定					
			nowProbability += PROBABILITY[iSum];
			if(rand<nowProbability){
				ansSlot[0]=iSum;
				break;
			}
		}
		//System.out.println(rand);
		
		for(int i=1;i<3;i++){
			nowProbability = 0;
			rand = Math.random();
			//System.out.println("乱数"+rand);
			for(int jSum=0;jSum<7;jSum++){//2個目,３個目の絵柄を決定					
				nowProbability += PROBABILITY[jSum];
				//System.out.println("**"+jSum+"**"+nowProbability);
				if(jSum == iSum){
					nowProbability +=(1-PROBABILITY[jSum])*variable;
					//System.out.println(nowProbability);
				}else{
					nowProbability -=PROBABILITY[jSum]*variable;
					//System.out.println("="+nowProbability);
				}
				if(rand<nowProbability){
					ansSlot[i]=jSum;
					break;
				}
			}
		}
				
		return ansSlot;
	}
	

	
	
	public String[] getProbabilityString(){
		double ansProbability[] = new double[7];
		String probability[] = new String[7];
		
		for(int i=0;i<7;i++){ 
			ansProbability[i]=PROBABILITY[i]*(PROBABILITY[i]+(1-PROBABILITY[i])*variable)*(PROBABILITY[i]+(1-PROBABILITY[i])*variable);
			float x = (int)(ansProbability[i]*10000);
			probability[i]=String.valueOf(x/100);//確立を小数点第２位まで表示する処理
		}
		return probability;
	}
}