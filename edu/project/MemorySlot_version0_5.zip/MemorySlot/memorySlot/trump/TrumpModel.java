package memorySlot.trump;
public class TrumpModel {

    private String suit;
    private int rank;
    private boolean open;
    
    public TrumpModel(String suit, int rank) {
        this.suit = suit;
        this.rank = rank;
        this.open = false; //裏向き
    }
    
    public void setOpen(boolean open) {this.open = open;} //Mediator実装クラスでも使うかも
    public boolean getOpen() {return open;}
    public String getSuit() {return suit;}
    public int getRank() {return rank;}
}