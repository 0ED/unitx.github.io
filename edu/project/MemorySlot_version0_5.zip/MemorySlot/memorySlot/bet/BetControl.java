package memorySlot.bet;
import memorySlot.Mediator;
import memorySlot.Colleague;
import java.lang.Integer;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Graphics;

public class BetControl extends MouseAdapter implements ActionListener, Colleague {
    private Mediator mediator;
    private BetModel betModel;
    private BetView betView;
    
    public BetControl(BetModel model, BetView view){
        this.betModel=model;
        this.betView=view;
        this.betView.addToLabelMouseListener(this);
        this.betView.addToButtonActionListener(this);
    }
    
    public void mouseClicked(MouseEvent ev){
        JLabel label = (JLabel) ev.getSource();
        
        /* 
         * クリックされたラベルの名前（1,5,10,25）の金額分、ベットを追加する。
         * また、その分スコアを減らす
         */
        for(int ci=0; ci<BetView.chips.length; ci++) {
            if(label.getName().equals(BetView.chips[ci])){
                betModel.addChip( Integer.parseInt(BetView.chips[ci]) );
                betView.repaint();
                //mediator.removeScoreByBet();
            }
        }
    }
    public void actionPerformed(ActionEvent ev){
        betModel.clearChip();
        betView.repaint();
    }
    
    
    /**
     * Mediator実装クラスからTrumpAreaを経由して呼び出し、Mediatorをセットするs
     * @param mediator メディエイター登録
     */
    public void setMediator(Mediator mediator) {
        this.mediator = mediator;
    }
}