package memorySlot.bet;

public class BetModel{
    private int chip;
    public BetModel(){
        clearChip();
    }
    public void addChip(int chip){
        if( this.chip+chip <= 75){
            this.chip+= chip;
        }
    }
    public int getChip(){return chip;}
    public void clearChip(){chip=0;}
}