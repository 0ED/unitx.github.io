package memorySlot;
import memorySlot.trump.TrumpModel;

public interface Mediator {
    public abstract void removeScoreByBet();
    public abstract void happenCardEvent(TrumpModel trump0, TrumpModel trump1, String trumpCombination);
    public abstract void hitSlot(int slotMark);
}