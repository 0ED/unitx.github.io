#! /usr/bin/env python
# -*- coding: utf-8 -*-

from jp.ac.kyoto_su.cse.pl.Bodies.Dragon import DragonModel
from jp.ac.kyoto_su.cse.pl.Bodies.Wasp import WaspModel
from jp.ac.kyoto_su.cse.pl.Bodies.Bunny import BunnyModel
from jp.ac.kyoto_su.cse.pl.Bodies.Penguin import PenguinModel
from jp.ac.kyoto_su.cse.pl.Bodies.Oni import OniModel
from jp.ac.kyoto_su.cse.pl.Bodies.Baby import BabyModel

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

class Example(object):
	"""例題プログラム：ドラゴンを実行する。"""
    
	@classmethod
	def main(self):
		"""ドラゴンを実行するメインプログラム。"""
		a_model = DragonModel()
		a_model.open()
	
		a_model = WaspModel()
		a_model.open()
	
		a_model = BunnyModel()
		a_model.open()
	
		a_model = PenguinModel()
		a_model.open()
	
		a_model = OniModel()
		a_model.open()
	
		a_model = BabyModel()
		a_model.open()
	
		glutMainLoop()

		return 0