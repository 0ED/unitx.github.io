#! /usr/bin/env python
# -*- coding: utf-8 -*-

"""パッケージに必要な「__initi__.py」ファイル。"""

# print "*** ac ***"