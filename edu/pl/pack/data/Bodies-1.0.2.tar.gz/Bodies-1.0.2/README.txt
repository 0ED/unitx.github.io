Bodies
=======

Copyright (C) 2013 IMAE Kengo, SAKIO Masaya, TAKAHASHI Tasuku, HASHIMOTO Risa, YAMAMOTO Yuta, YAMASHITA Satoru All Rights Reserved.

Company name is MiniCola. The member is IMAE Kengo, SAKIO Masaya, TAKAHASHI Tasuku, HASHIMOTO Risa, YAMAMOTO Yuta, YAMASHITA Satoru.
Bodies is open source software. And, The software draw 3D modeling.
if you'd like to test Bodies, Type as below to Terminal.app.

	make 
	make test

if you'd like to install Bodies, Type as below to Terminal.app.

	make
	make install

And, open Bodies.app by double click.
We use as reference by AOKI Atsushi, One's predecessors of Smalltalk.
The reference puts to below.
http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/Python/DragonPrgrammingProcess/index-j.html

